This folder contains support files for the SCWorkshop software.

You should not normally need to make changes here.
