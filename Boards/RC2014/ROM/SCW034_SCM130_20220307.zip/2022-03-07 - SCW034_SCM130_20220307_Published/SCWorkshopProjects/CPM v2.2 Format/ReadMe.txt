Format CF128

This project creates a version of the CP/M Format utility for 64MB or 128MB 
Compact Flash cards.

It is Grant Searle's code, modified for use with Small Computer Workshop IDE.

Also the Compact Flash ready test has been improved and DRQ ready test added.

Compatible with LiNC80 and RC2014 systems.

SCC 2018-04-30
