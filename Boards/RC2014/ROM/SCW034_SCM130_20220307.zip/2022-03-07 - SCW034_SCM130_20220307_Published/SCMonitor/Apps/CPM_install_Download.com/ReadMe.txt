Install DOWNLOAD.COM to compact flash

This program is for the LiNC80, Z50Bus, and RC2014.

This program is written as an App for the Small Computer Monitor v1.0

It is used to install DOWNLOAD.COM on to a formatted Compact Flash 
card containing CP/M.

There are several versions of the .HEX file:
SCM_Install_Download_LiNC80_code8000.hex
SCM_Install_Download_Z80_code8000.hex
SCM_Install_Download_Z180_code8000.hex

Filename format: 
"SCM_Install_Download"_<processor(s)>_<storage-device-and-address>_<code-start-address>

The filename indicates the hardware it is designed for:
The processor or system is either LiNC80, Z80, or Z180
The code loads and runs from the indicates code address


Send the hex file to the Small Computer Monitor using a terminal program.

Start the program with the SCMonitor command "G 8000"

Following the instructions displayed on the terminal.

LiNC80 version written by Jon Langseth
